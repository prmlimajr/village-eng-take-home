# Take Home Exercise

## Welcome

Hello and welcome to the Village Engineering take home exercise!

We'd like to create a simple full-stack application that scrapes restaurant availability and displays the results. The detailed requirements for both the backend and frontend are listed below.

## Getting Started

This repo includes the following packages/apps:

### Apps and Packages

- `web`: a [Next.js](https://nextjs.org/) app
- `@repo/database`: Drizzle ORM wrapper to manage & access the database
- `@repo/ui`: a stub React component library shared by a `web` application
- `@repo/eslint-config`: `eslint` configurations (includes `eslint-config-next` and `eslint-config-prettier`)
- `@repo/typescript-config`: `tsconfig.json`s used throughout the monorepo

### Utilities

This repo has some additional tools already setup for you:

- [Turbo](https://turbo.build/) for monorepo management
- [pNPM](https://pnpm.io/) for package management
- [TypeScript](https://www.typescriptlang.org/) for static type checking
- [ESLint](https://eslint.org/) for code linting
- [Prettier](https://prettier.io) for code formatting
- [Drizzle](https://orm.drizzle.team/) for database ORM
- [Vitest](https://vitest.dev/) for test suites
- [Next.js](https://nextjs.org/) for frontend (using pages router)
- [React](https://reactjs.org/) for frontend components
- [tRPC](https://trpc.io/) for typesafe frontend APIs

### Commands

- Install dependencies: `pnpm install`
- Generate a new database migration: `turbo db:generate`
- Migrate the database: `turbo db:migrate`
- Explore the database in browser: `turbo db:studio`
- Run the linter: `turbo lint`
- Start the dev server: `turbo dev`
- Run the test suite: `turbo test`

## Backend Requirements

You will be working in the file `scrape.ts`. There is a test suite in `scrape.test.ts` that you can use to test your implementation.

Assume the `SlotsAPI` is an external API that returns available restaurant reservation slots for a given day and seats pair. Assume you are unable to change the `SlotsAPI` and do not worry about the implementation of this API.

Your task is to store the returned slots in the database. Each slot has a unique token which is a combination of the day, seats, and time. The database should be accessed using the `db` object exported from `@repo/database`.

The scraper should be able to efficiently create new availabilities it's never seen before and mark existing availabilities as available or unavailable.

For example, the scraper should efficiently handle the following scenario:
- The API returns one slot. We don't have that slot in our database so we store it.
- Time passes and the API only returns zero slots. We mark the slot we stored as unavailable.
- Time passes and the API returns that same slot again. We mark the slot we stored as available.

The test suite in `scrape.test.ts` should help you test your implementation. Please make sure to run `pnpm test` to run the test suite and that all tests pass.

The most optimized solution only needs a maximum of four database queries per `scrape()` call. If your solution requires more than four queries, please consider whether you can refactor your code to make it more efficient.

## Frontend Requirements

You will be working in the file `pages/index.tsx`. We've already setup a tRPC router to return the availability for a given day and seats pair.

Please create a very simple UI for the frontend that displays the availability for a given day and seats pair. The UI should be able to filter the availability by day and seats pair.

You're welcome to add a library like Tailwind or something similar to make the UI look nicer.

## Tips

- Search the codebase for `// TODO` to find all the places where things need to be implemented.
- To try and make things less confusing, consider `slots` to be currently available tables that are returned by the API and consider `avails` to be current and past available tables that are stored in our database.
- You do not need to do anything more than meet the listed requirements. Where a requirement is ambiguous, please choose any working solution to it and be prepared to explain why you chose that solution.
- You shouldn't need more than two hours to complete this assesement. Please send us an email if you're stuck on something.
- Please avoid adding any new packages, scripts, or other external dependencies to this project. Some lightweight frontend libraries like Tailwind are fine.
- I recommend aliasing the `pnpm`, `git`, and `turbo` commands to something shorter to speed up your workflow. On MacOS you can do this by adding the following to your `~/.zprofile` file:

```
alias p='pnpm'
alias t='turbo'
alias g='git'
```

## Submission

When you're ready to submit your work, please run `zip-it.sh` to create a zip file of your codebase.

Please upload this file somewhere publicly accessible and send us the link. Email providers often block compressed files so please don't send the file itself over email.
