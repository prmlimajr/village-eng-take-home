import dayjs from "dayjs";
import got, { Got } from "got";

interface Slot {
  day: string;
  time: string;
  seats: number;
  token: string;
}

export class SlotsAPI {

  //
  // Get the currently available slots for a given day and seats
  //
  // i simulates time passing
  //
  // Pretend this is an opaque, 3rd party API. There's no need to understand the logic.
  //
  // Do NOT edit this function.
  //

  public async getSlots(day: string, seats: number, i: number): Promise<Slot[]> {
    if (Number.isNaN(seats) || seats < 1 || seats > 4) {
      throw new Error("Invalid seats (should be between 1 and 4)")
    }

    const parsedDay = dayjs(day, "YYYY-MM-DD")
    if (!parsedDay.isValid() || parsedDay.isBefore(dayjs().subtract(1, "day"))) {
      throw new Error("Invalid day (should be a valid date in the future)")
    }

    if (i < 0 || i > 4) {
      throw new Error("Invalid i (should be between 0 and 4)")
    }

    const slots = []
    const hashInt = parsedDay.month() * 1_000 + parsedDay.date() * 10 + seats
    const numTables = i
    const uniqueTokens = new Set<string>()

    for (let i = 0; i < numTables; i++) {
      const hour = 17 + this.floorAbsCos(hashInt + 10 + i, 0, 6)
      const minute = ["00", "15", "30", "45"][this.floorAbsCos(hashInt + 100 + i, 0, 4)]
      const time = `${hour}:${minute}`
      const token =  `${day}/${time}/${seats}/Dining Room`

      if (uniqueTokens.has(token)) {
        continue
      }

      uniqueTokens.add(token)

      slots.push({
        seats,
        day,
        time,
        token,
      })
    }

    // Simulate a tiny delay of 50ms as if we're calling an API
    await new Promise(resolve => setTimeout(resolve, 5))

    return slots
  }

  // Returns a number in [min, max) for a given hash value
  private floorAbsCos(hash: number, min: number, max: number) {
    const val = Math.floor(Math.abs(Math.cos(hash) * 10))

    return Math.floor(val % (max - min)) + min
  }

}

export const slotsApi = new SlotsAPI();
