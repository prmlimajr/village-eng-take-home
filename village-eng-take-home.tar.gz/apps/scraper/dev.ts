// An example scraper that fetches new availabilities every 30 seconds

import { scrape } from './scrape';

async function main() {
  let i = 1;

  while (true) {
    i = (i + 1) % 4;

    console.log(`Fetching new availabilities (${i})...`);

    await scrape(i);

    console.log(`Done!`);

    await new Promise((resolve) => setTimeout(resolve, 5_000));
  }
}

main();
