export async function getSlots(date: string, seats: number) {
  return []
}
