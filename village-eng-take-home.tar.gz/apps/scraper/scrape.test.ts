import { avails, db } from '@repo/database';
import { afterEach, beforeEach, expect, it } from 'vitest';
import { scrape } from './scrape';

// Reset data before and after each test
beforeEach(async () => {
  await db.delete(avails);
});

afterEach(async () => {
  await db.delete(avails);
});

async function getAvails() {
  return (await db.select().from(avails).orderBy(avails.token)).map((x) => {
    return {
      day: x.day,
      time: x.time,
      seats: x.seats,
      available: x.available,
    };
  });
}

it('1. creates avails', async () => {
  await scrape(2);

  expect(await getAvails()).toStrictEqual([
    { day: '2024-10-01', time: '17:45', seats: 4, available: 1 },
    { day: '2024-10-01', time: '18:15', seats: 2, available: 1 },
    { day: '2024-10-01', time: '19:15', seats: 4, available: 1 },
    { day: '2024-10-01', time: '20:45', seats: 2, available: 1 },
    { day: '2024-10-02', time: '17:15', seats: 2, available: 1 },
    { day: '2024-10-02', time: '20:30', seats: 4, available: 1 },
    { day: '2024-10-02', time: '20:45', seats: 2, available: 1 },
  ]);
});

it('2. marks existing avails as unavailable', async () => {
  await scrape(2);
  await scrape(1);

  expect(await getAvails()).toStrictEqual([
    { day: '2024-10-01', time: '17:45', seats: 4, available: 0 },
    { day: '2024-10-01', time: '18:15', seats: 2, available: 1 },
    { day: '2024-10-01', time: '19:15', seats: 4, available: 1 },
    { day: '2024-10-01', time: '20:45', seats: 2, available: 0 },
    { day: '2024-10-02', time: '17:15', seats: 2, available: 0 },
    { day: '2024-10-02', time: '20:30', seats: 4, available: 1 },
    { day: '2024-10-02', time: '20:45', seats: 2, available: 1 },
  ]);
});

it('3. marks existing avails as available', async () => {
  await scrape(2);
  await scrape(1);
  await scrape(2);

  expect(await getAvails()).toStrictEqual([
    { day: '2024-10-01', time: '17:45', seats: 4, available: 1 },
    { day: '2024-10-01', time: '18:15', seats: 2, available: 1 },
    { day: '2024-10-01', time: '19:15', seats: 4, available: 1 },
    { day: '2024-10-01', time: '20:45', seats: 2, available: 1 },
    { day: '2024-10-02', time: '17:15', seats: 2, available: 1 },
    { day: '2024-10-02', time: '20:30', seats: 4, available: 1 },
    { day: '2024-10-02', time: '20:45', seats: 2, available: 1 },
  ]);
});

it('4. creates more new avails', async () => {
  await scrape(2);
  await scrape(1);
  await scrape(2);
  await scrape(4);

  expect(await getAvails()).toStrictEqual([
    { day: '2024-10-01', time: '17:45', seats: 2, available: 1 },
    { day: '2024-10-01', time: '17:45', seats: 4, available: 1 },
    { day: '2024-10-01', time: '18:15', seats: 2, available: 1 },
    { day: '2024-10-01', time: '19:15', seats: 2, available: 1 },
    { day: '2024-10-01', time: '19:15', seats: 4, available: 1 },
    { day: '2024-10-01', time: '20:15', seats: 4, available: 1 },
    { day: '2024-10-01', time: '20:30', seats: 4, available: 1 },
    { day: '2024-10-01', time: '20:45', seats: 2, available: 1 },
    { day: '2024-10-02', time: '17:15', seats: 2, available: 1 },
    { day: '2024-10-02', time: '18:15', seats: 4, available: 1 },
    { day: '2024-10-02', time: '19:45', seats: 4, available: 1 },
    { day: '2024-10-02', time: '20:30', seats: 2, available: 1 },
    { day: '2024-10-02', time: '20:30', seats: 4, available: 1 },
    { day: '2024-10-02', time: '20:45', seats: 2, available: 1 },
  ]);
});

it('5. marks more new avails as unavailable', async () => {
  await scrape(2);
  await scrape(1);
  await scrape(2);
  await scrape(4);
  await scrape(3);

  expect(await getAvails()).toStrictEqual([
    { day: '2024-10-01', time: '17:45', seats: 2, available: 0 },
    { day: '2024-10-01', time: '17:45', seats: 4, available: 1 },
    { day: '2024-10-01', time: '18:15', seats: 2, available: 1 },
    { day: '2024-10-01', time: '19:15', seats: 2, available: 1 },
    { day: '2024-10-01', time: '19:15', seats: 4, available: 1 },
    { day: '2024-10-01', time: '20:15', seats: 4, available: 0 },
    { day: '2024-10-01', time: '20:30', seats: 4, available: 1 },
    { day: '2024-10-01', time: '20:45', seats: 2, available: 1 },
    { day: '2024-10-02', time: '17:15', seats: 2, available: 1 },
    { day: '2024-10-02', time: '18:15', seats: 4, available: 1 },
    { day: '2024-10-02', time: '19:45', seats: 4, available: 0 },
    { day: '2024-10-02', time: '20:30', seats: 2, available: 1 },
    { day: '2024-10-02', time: '20:30', seats: 4, available: 1 },
    { day: '2024-10-02', time: '20:45', seats: 2, available: 1 },
  ]);
});

it('6. marks more new avails as available', async () => {
  await scrape(2);
  await scrape(1);
  await scrape(2);
  await scrape(4);
  await scrape(3);
  await scrape(4);

  expect(await getAvails()).toStrictEqual([
    { day: '2024-10-01', time: '17:45', seats: 2, available: 1 },
    { day: '2024-10-01', time: '17:45', seats: 4, available: 1 },
    { day: '2024-10-01', time: '18:15', seats: 2, available: 1 },
    { day: '2024-10-01', time: '19:15', seats: 2, available: 1 },
    { day: '2024-10-01', time: '19:15', seats: 4, available: 1 },
    { day: '2024-10-01', time: '20:15', seats: 4, available: 1 },
    { day: '2024-10-01', time: '20:30', seats: 4, available: 1 },
    { day: '2024-10-01', time: '20:45', seats: 2, available: 1 },
    { day: '2024-10-02', time: '17:15', seats: 2, available: 1 },
    { day: '2024-10-02', time: '18:15', seats: 4, available: 1 },
    { day: '2024-10-02', time: '19:45', seats: 4, available: 1 },
    { day: '2024-10-02', time: '20:30', seats: 2, available: 1 },
    { day: '2024-10-02', time: '20:30', seats: 4, available: 1 },
    { day: '2024-10-02', time: '20:45', seats: 2, available: 1 },
  ]);
});
