import { db, avails } from '@repo/database';
import { inArray, eq } from 'drizzle-orm';
import { slotsApi } from './SlotsAPI';

// This is a helper type you might find useful when creating new avails
type NewAvail = typeof avails.$inferInsert;

/*

How to use Drizzle:

db.select().from(avails)
db.insert(avails).values(...)
db.update(avails).set(...).where(inArray(avails.column, values))

*/

// `i` simulates time passing
export async function scrape(i: number) {
  const existingInDb = await db.select().from(avails);

  const toBeInserted = [];
  const toBeUpdatedAsUnavailable = [];
  const toBeUpdatedAsAvailable = [];

  for (const day of ['2024-10-01', '2024-10-02']) {
    const existingInThatDay = existingInDb.filter((item) => item.day === day);

    for (const seats of [2, 4]) {
      const slots = await slotsApi.getSlots(day, seats, i);
      const slotTokens = slots.map((slot) => slot.token);

      for (const existing of existingInThatDay) {
        if (existing.seats === seats && !slotTokens.includes(existing.token)) {
          toBeUpdatedAsUnavailable.push(existing);
        }
      }

      for (const slot of slots) {
        const alreadyExists = existingInThatDay.find(
          (item) => item.token === slot.token
        );

        if (!alreadyExists) {
          const newAvail: NewAvail = {
            seats,
            day,
            time: slot.time,
            token: slot.token,
            available: 1,
          };

          toBeInserted.push(newAvail);
        } else {
          if (alreadyExists.available === 0) {
            toBeUpdatedAsAvailable.push(alreadyExists);
          }
        }
      }
    }
  }

  if (toBeInserted.length > 0) {
    await db.insert(avails).values(toBeInserted);
  }

  if (toBeUpdatedAsUnavailable.length > 0) {
    await db
      .update(avails)
      .set({ available: 0 })
      .where(
        inArray(
          avails.token,
          toBeUpdatedAsUnavailable.map((item) => item.token)
        )
      );
  }

  if (toBeUpdatedAsAvailable.length > 0) {
    await db
      .update(avails)
      .set({ available: 1 })
      .where(
        inArray(
          avails.token,
          toBeUpdatedAsAvailable.map((item) => item.token)
        )
      );
  }
}
