interface FooterProps {
  developer: string;
  linkedin: string;
}

export function Footer({ developer, linkedin }: FooterProps) {
  return (
    <footer>
      <p>
        <a href={linkedin} target="_blank">
          Made by {developer}
        </a>
      </p>
    </footer>
  );
}
