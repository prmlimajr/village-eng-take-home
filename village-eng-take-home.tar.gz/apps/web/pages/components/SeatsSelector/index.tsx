interface SeatsSelectorProps {
  seats: number;
  onClick: () => void;
}

export function SeatsSelector({ seats, onClick }: SeatsSelectorProps) {
  return (
    <div onClick={onClick}>
      <span>{seats}</span>
    </div>
  );
}
