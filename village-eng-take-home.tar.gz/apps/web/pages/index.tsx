import { useEffect, useState } from 'react';
import { trpc } from '../utils/trpc';
import { SeatsSelector } from './components/SeatsSelector';
import { Footer } from './components/Footer';
import Image from 'next/image';

interface Available {
  available: number;
  day: string;
  id: number;
  seats: number;
  time: string;
  token: string;
}

export default function IndexPage() {
  const [day, setDay] = useState('2024-10-01');
  const [seats, setSeats] = useState(2);
  const [availables, setAvailables] = useState<Available[]>([]);

  const avails = trpc.avails.useQuery({ seats, day });

  useEffect(() => {
    if (avails.data) {
      setAvailables(avails.data.filter((avail) => avail.available === 1));
    } else {
      setAvailables([]);
    }
  }, [avails.data]);

  const handleChangeSeats = (seats: number) => {
    setSeats(seats);

    avails.refetch();
  };

  const checkIfNotAvailable = () => {
    return availables.every((avail) => avail.available === 0);
  };

  if (!avails.data) {
    return <div>Loading...</div>;
  }

  return (
    <main>
      <Image
        src="/images/restaurant-svgrepo-com.svg"
        alt="Logo"
        width={200}
        height={200}
      />
      <div>
        <section>
          <h1>Select the date to check for availability:</h1>
          <input
            type="date"
            value={day}
            onChange={(e) => setDay(e.target.value)}
          />
        </section>

        <section>
          <h1>How many seats you need?</h1>

          <div>
            <SeatsSelector seats={2} onClick={() => handleChangeSeats(2)} />

            <SeatsSelector seats={4} onClick={() => handleChangeSeats(4)} />
          </div>
        </section>
      </div>

      {checkIfNotAvailable() ? (
        <p>
          No tables for {seats} on {day}{' '}
        </p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Time</th>
              <th>Seats</th>
            </tr>
          </thead>
          <tbody>
            {availables
              .sort((a, b) => a.time.localeCompare(b.time))
              .map((avail) => (
                <tr key={avail.id}>
                  <td>{avail.time}</td>
                  <td>{avail.seats}</td>
                </tr>
              ))}
          </tbody>
        </table>
      )}

      <Footer
        developer="Paulo Lima"
        linkedin="https://www.linkedin.com/in/prmlimajr/?locale=en_US"
      />
    </main>
  );
}
