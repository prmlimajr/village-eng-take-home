import { z } from 'zod';
import { procedure, router } from '../trpc';
import { avails, db } from '@repo/database';
import { eq, and } from "drizzle-orm"

export const appRouter = router({
  avails: procedure
    .input(
      z.object({
        day: z.string(),
        seats: z.number(),
      }),
    )
    .query((opts) => {
      return db.select().from(avails).where(and(eq(avails.day, opts.input.day), eq(avails.seats, opts.input.seats)))
    }),
});

// export type definition of API
export type AppRouter = typeof appRouter;
