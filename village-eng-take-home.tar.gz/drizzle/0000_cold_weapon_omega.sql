CREATE TABLE `avails` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`seats` integer NOT NULL,
	`day` text NOT NULL,
	`time` text NOT NULL,
	`token` text(256) NOT NULL,
	`available` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `avails_token_unique` ON `avails` (`token`);