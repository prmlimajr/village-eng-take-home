import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const avails = sqliteTable('avails', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  seats: integer('seats').notNull(),
  day: text('day').notNull(),
  time: text('time').notNull(),
  token: text('token', { length: 256 }).unique().notNull(), // Unique token
  available: integer('available').notNull(), // 0 or 1 as boolean. SQLite does not have a boolean type
});
