#!/bin/bash
TAR_FILE="../village-eng-take-home.tar.gz"
FOLDER_TO_TAR="."
tar --exclude="node_modules" --exclude=".git" --exclude=".next" --exclude=".turbo" --exclude=".DS_Store" -cvzf $TAR_FILE $FOLDER_TO_TAR
echo "Gzipped into $TAR_FILE"
